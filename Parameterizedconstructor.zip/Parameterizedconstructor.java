package secondjava;

public class Parameterizedconstructor {
	 int stud_id;  
	    String stud_name;  
	    
	    Parameterizedconstructor (int i,String s){  
	    stud_id = i;  
	    stud_name = s;  
	    }  
	      
	    void show(){
	    	System.out.println("student id and name are:"+ stud_id+","+stud_name);
	    	}  
	   
	    public static void main(String args[]){  
	    
	    	Parameterizedconstructor s1 = new Parameterizedconstructor(101,"David");  
	    	Parameterizedconstructor s2 = new Parameterizedconstructor(102,"Dennnis");  
	     
	    s1.show();  
	    s2.show();  
	   }  
	
	

}
